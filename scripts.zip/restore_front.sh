#!/bin/bash

unzip wordpress.zip -d wordpress
docker cp ./wordpress/. wordpress:/var/www/html
 