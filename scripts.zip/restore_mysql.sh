#!/bin/bash
source ./.env
docker exec -i db sh -c 'exec mysql -u$MYSQL_USER -p$MYSQL_PASSWORD $MYSQL_DATABASE' < ./backup-db/data.sql