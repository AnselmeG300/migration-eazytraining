#!/bin/bash
sudo mkfs -t xfs /dev/xvdh
sudo mkdir -p /home/centos/eazytraining
sudo mount /dev/xvdh /home/centos/eazytraining
UUID_VALUE=$(sudo blkid | grep '/dev/xvdh' | awk -F'\"' '{print $2}')
echo "UUID=${UUID_VALUE}  /home/centos/eazytraining  xfs  defaults,nofail  0  2" | sudo tee -a /etc/fstab